let suma1 = 0
let numero1 = 5
while(numero1 <= 1000)  {
    suma1 = suma1 + numero1;
    numero1 = numero1 + 5;
}
console.log(`La suma de todos los múltiplos de 5 menores o iguales que 10000 es ${suma1}`);
