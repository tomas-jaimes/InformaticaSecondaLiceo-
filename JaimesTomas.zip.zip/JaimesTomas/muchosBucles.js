let suma = 0
let numero = 3
while(numero <= 1000)  {
    suma = suma + numero;
    numero = numero + 3;
}
console.log(`La suma de todos los múltiplos de 3 menores o iguales que 10000 es ${suma}`);
