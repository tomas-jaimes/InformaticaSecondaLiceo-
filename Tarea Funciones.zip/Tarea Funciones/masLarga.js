function masLarga(palabra1 , palabra2) {
   let largo1 = palabra1.lenght;
   let largo2 = palabra2.lenght;
   let palabraLarga="";
   if(largo1>largo2) {
       return palabraLarga=palabra1
   }
   else if(largo2>largo1) {
       return palabraLarga=palabra2
   }
}