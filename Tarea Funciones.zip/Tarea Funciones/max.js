function numeroMax(a , b) {
    if(a>b) {
        return a;
    }
    else if(b>a) {
        return b;
    }
}